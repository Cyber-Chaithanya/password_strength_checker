# Python Learning Journey

A collection of Python practice programs, OOP learning materials, and beginner projects created while building programming fundamentals.

## Repository contents

- `programs/` — Python practice programs and a Jupyter notebook.
- `OOPS-learning/` — class examples, OOP notes, guide-generation scripts, and related learning assets.
- `output/` — generated OOP study guide and diagrams.
- `passsword/` — password-strength checker practice project. The folder name is kept as it appeared in the original project.

## Getting started

1. Install Python 3.
2. Clone or download this repository.
3. Open the folder in VS Code.
4. Run a Python file from the terminal, for example:

   ```bash
   python programs/program-1.py
   ```

   Replace the path with the file you want to run. Some programs expect interactive input.

## Learning goals

Practice Python fundamentals, functions, strings, collections, object-oriented programming, and small beginner projects. This repository is a learning portfolio; individual files may represent exercises or alternate attempts.
